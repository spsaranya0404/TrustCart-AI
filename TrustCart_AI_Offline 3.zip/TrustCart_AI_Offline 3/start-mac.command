#!/bin/bash
# TrustCart AI - offline launcher (macOS). Double-click, or right-click > Open the first time.
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed. Install the LTS version from https://nodejs.org (one time), then run this again."
  read -n 1 -s -r -p "Press any key to close..."; exit 1
fi
export OFFLINE_MODE=1 NODE_ENV=production PORT=${PORT:-3000}
echo "Starting TrustCart AI (offline mode) on http://localhost:$PORT"
( sleep 2; open "http://localhost:$PORT" ) &
node server.mjs
