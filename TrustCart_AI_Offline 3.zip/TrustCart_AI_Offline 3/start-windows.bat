@echo off
rem TrustCart AI - offline launcher (Windows). Double-click to run.
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Install the LTS version from https://nodejs.org ^(one time^), then run this again.
  pause
  exit /b 1
)
set OFFLINE_MODE=1
set NODE_ENV=production
if "%PORT%"=="" set PORT=3000
echo Starting TrustCart AI (offline mode) on http://localhost:%PORT%
start "" cmd /c "timeout /t 2 >nul & start http://localhost:%PORT%"
node server.mjs
pause
