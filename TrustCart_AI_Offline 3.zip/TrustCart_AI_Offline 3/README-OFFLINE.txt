TRUSTCART AI - OFFLINE PACKAGE
==============================

One-time setup (needs internet, do it BEFORE judging)
  1. Install Node.js "LTS" from https://nodejs.org  (version 18 or newer).
  2. Unzip this folder anywhere (Desktop is fine).

Run
  Mac:      double-click  start-mac.command
            (first time: right-click > Open > Open, because macOS blocks unsigned scripts)
            Or open Terminal, type:  cd <folder path>
            then:  OFFLINE_MODE=1 NODE_ENV=production node server.mjs
  Windows:  double-click  start-windows.bat
  Then open  http://localhost:3000  in Chrome if it does not open by itself.

Offline test
  Turn Wi-Fi OFF, restart the launcher, reload the page, click through every tab.
  Everything runs on this computer. No API key and no internet are needed.

Stop
  Close the terminal window, or press Ctrl+C.

Notes
  - Answers come from the built-in 5,000-item catalogue and policies, with citations.
  - Offline mode never calls Gemini. The language-model call is skipped on purpose.
  - If port 3000 is busy, use another port: PORT=3001 (Mac) or set PORT=3001 (Windows).
